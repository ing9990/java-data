package �߰���;

public class Member extends Person  {

	private String id;
	
	Member(String name, int age) {
		super(name, age);
		
	}
	
	Member(String name,int age,String id){
		super(name,age);
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
