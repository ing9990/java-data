package ���α׷���_����_5��;

class Phone{
	protected String owner;
	
	Phone(String owner){
		this.owner = owner;
	}
	void talk() {
		System.out.printf("%s�� ��ȭ��.\n",owner);
	}
	public void autoAnswering() {
		// TODO Auto-generated method stub
		
	}
	public void playGame() {
		// TODO Auto-generated method stub
		
	}
	
}

class Telephone extends Phone{
	private String when;
	
	Telephone(String owner , String when){
		super(owner);
		this.when = when;
	}
	
	@Override
	public void autoAnswering() {
		System.out.printf("%s�� ������ %s ��ȭ ���.\n",owner,when);
	}
	
}

class Smartphone extends Telephone{
	private String game;
	
	Smartphone(String owner ,String when,String game){
		super(owner,when);
		this.game = game;
	}
	
	Smartphone(String owner,String game){
		super(owner, game);
		this.game = game;
	}
	
	@Override
	public void playGame() {
		System.out.printf("%s�� %s ������.\n",owner,game);
	}
}



public class Main {

	public static void main(String[] args) {
		
		Phone[] phones = {new Phone("Ȳ����"),new Telephone("�浿��","����"),new Smartphone("�α���","��Ÿũ����Ʈ")};

		phones[0].talk();
		phones[1].autoAnswering();
		phones[2].playGame();
	}

}
