package ���α׷���_����_3��;

class Point{
	
	private int x,y;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	Point(int x,int y){
		this.x = x;
		this.y = y;
	}
	
	public void ToString() {
		System.out.printf("x��ǥ : %4d\ty��ǥ : %4d\n",getX(),getY());
	}
}

class MovablePoint extends Point{
	
	private int xSpeed,ySpeed;
	
	MovablePoint(int x , int y,int xSpeed,int ySpeed){
		super(x,y);
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
	}

	public int getxSpeed() {
		return xSpeed;
	}

	public void setxSpeed(int xSpeed) {
		this.xSpeed = xSpeed;
	}

	public int getySpeed() {
		return ySpeed;
	}

	public void setySpeed(int ySpeed) {
		this.ySpeed = ySpeed;
	}
	
	@Override
	public void ToString() {
		System.out.printf("x��ǥ : %4d\ty��ǥ : %4d\txSpeed : %4d\tySpeed : %4d\n",getX(),getY(),xSpeed,ySpeed);
	}
}


public class Main {

	public static void main(String[] args) {
		
		Point p1 = new Point(5,10);
		Point p2 = new MovablePoint(5,10,5,5);

		p1.ToString();
		p2.ToString();
			
	}
}
