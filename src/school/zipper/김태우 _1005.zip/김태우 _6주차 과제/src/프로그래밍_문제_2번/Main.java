package ���α׷���_����_2��;

import java.util.ArrayList;

class Person{
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	private String name;
	private int age;
	
	Person(String name,int age){
		this.name = name;
		this.age = age;
	}
	
	public void show() {
		System.out.printf("�̸�:%4s\t����:%4d\n",name,age);
	}
	

}

class Student extends Person{
	
	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	private String no;
	
	Student(String name,int age,String no){
		super(name,age);
		this.no = no;
	}
	
	@Override
	public void show() {
		System.out.printf("�̸�:%4s\t����:%4d\t�й�:%4s\n",getName(),getAge(),no);
	}

	
	
}

class ForeignStudent extends Student{
	
	private String contry;
	
	ForeignStudent(String name,int age,String no,String contry){
		super(name,age,no);
		this.contry = contry;
	}

	public String getContry() {
		return contry;
	}

	public void setContry(String contry) {
		this.contry = contry;
	}
	
	@Override
	public void show() {
		System.out.printf("�̸�:%4s       \t����:%4d\t�й�:%4s\t����:%4s\n",getName(),getAge(),getNo(),contry);
	}

	
}

public class Main {

	
	public static void main(String[] args) {
		
		ArrayList<Person> p = new ArrayList<>();
		
		
		p.add( new Person("�浿��",22));
		p.add(new Student("Ȳ����",23,"100"));
		p.add(new ForeignStudent("Amy",30,"200","U.S.A"));
	
		
		for(Person v : p)
			v.show();
	}
}