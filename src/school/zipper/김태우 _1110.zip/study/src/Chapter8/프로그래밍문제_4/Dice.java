package Chapter8.���α׷��ֹ���_4;

import java.util.Random;

public class Dice {
	
	Random r = new Random();

	public int roll() {
		return (int)(Math.random()*6+1);
	}
}
