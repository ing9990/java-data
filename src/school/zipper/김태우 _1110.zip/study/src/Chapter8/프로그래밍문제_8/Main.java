package Chapter8.���α׷��ֹ���_8;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		
		StringTokenizer st = new StringTokenizer(s," ");
		
		String[] arr = new String[st.countTokens()];
		int v = st.countTokens();
		for (int i = 0; i<arr.length; i++) 
			arr[i] = st.nextToken();
		Arrays.sort(arr);
		System.out.println("�ܾ� ���� : " + v);
		System.out.print("���ĵ� ��ū : ");
		
		for ( int i = 0; i< arr.length; i++) {
			if (i == arr.length-1) {
				System.out.println(arr[i]);
				break;
			}
			System.out.print(arr[i]+", ");
		}
	
	}
}
