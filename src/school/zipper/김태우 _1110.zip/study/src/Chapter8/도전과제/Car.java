package Chapter8.��������;

public class Car {

	private String model;
	
	public Car(String model) {
		this.model = model;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	@Override
	public String toString() {
		
		return model;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Car) {
			obj = ((Car) obj);
			if(((Car) obj).model == model) {
				return true;
			}else {
				return false;
			}
		}
		return super.equals(obj);
	}

	public boolean equals() {
		// TODO Auto-generated method stub
		return false;
	}
		
}

