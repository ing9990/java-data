package Chapter8.���α׷��ֹ���_2;

public class Student {

	String name;
	
	public Student(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "�л� ["+this.name+"]";
	}
	
}
