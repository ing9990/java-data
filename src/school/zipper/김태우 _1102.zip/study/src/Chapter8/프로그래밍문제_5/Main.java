package Chapter8.���α׷��ֹ���_5;

public class Main {
	
	public static void show(Object o) {
		System.out.println(o.toString());
	}
	
	public static void main(String[] args) {
		
		show(new String("���"));
		show(new StringBuilder("meltdown"));
		show(new StringBuffer("!@#"));
	
	}

}
