package Chapter8.���α׷��ֹ���_1;

public class Circle {
	int r;
	
	public Circle(int r) {
		this.r = r;
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Circle) {
			o = ((Circle)o);
			
			if (((Circle) o).r == this.r) {
				return true;
			}else {
				return false;
			}
		}
		
		return false;
	}

}
