package Chapter8.��������;

public class MyCar extends Car{

	public MyCar(String model) {
		super(model);
	}
	
	@Override
	public String toString() {
		
		return getModel();
	}
	
	@Override
	public boolean equals(Object o) {
		if (o instanceof Car) {
			if((boolean) (o = ((Car)o).getModel() == this.getModel())) {
				return true;
			}else {
				return false;
			}
		}
		return false;
	}

	
}
