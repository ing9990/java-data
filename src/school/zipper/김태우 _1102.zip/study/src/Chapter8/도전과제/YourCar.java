package Chapter8.��������;

public class YourCar extends Car{

	public YourCar(String model) {
		super(model);
	}
	
	@Override
	public String toString() {
		return null;
	}
}
