package Chapter8.���α׷��ֹ���_4;

import java.util.Random;


public class Dice {
	
	Random r = new Random();

	public int roll() {
		int a;
		
		a = (int)(Math.random()*6+1);
		
		return a;
	}
}
