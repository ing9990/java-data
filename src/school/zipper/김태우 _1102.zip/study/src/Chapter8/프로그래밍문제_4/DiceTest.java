package Chapter8.���α׷��ֹ���_4;

public class DiceTest {

	public static void main(String[] args) {
		
		System.out.println(new Dice().roll());

	}

}
