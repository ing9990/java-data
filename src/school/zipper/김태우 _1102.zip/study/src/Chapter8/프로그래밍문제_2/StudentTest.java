package Chapter8.���α׷��ֹ���_2;

public class StudentTest {

	public static void main(String[] args) {
		
		Student s1 = new Student("ȫ�浿");
		Student s2 = new Student("���");

		System.out.println(s1.toString());
		System.out.println(s2.toString());
	}

}
