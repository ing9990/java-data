import java.util.Scanner;

public class oddEven {


	enum OddEven{
		
		Ȧ("odd"),¦("even");
		
		private String eng;
		
		OddEven(String eng){
			this.eng = eng;
		}
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num;
		
		while(true) {
			
			System.out.printf("�� �Է� :");
			num = sc.nextInt();
			
			if(num==-1)
				break;
			else if(num%2==0)
				System.out.println(OddEven.¦);
			else
				System.out.println(OddEven.Ȧ);
		}

	}

}
