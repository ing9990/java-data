import java.util.Scanner;

public class _��������_1�� {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num;
		
		System.out.print("�л� �� �Է� : ");
		num = sc.nextInt();
		
		int[] scores = new int[num];
		
		for(int i =0; i<scores.length; i++)
		{
			int data ;
			System.out.print("�����Է� : ");
			data = sc.nextInt();
			scores[i] = data;
		}
		
		for(int v:scores)
			System.out.println(v);
		
	}

}
