package poly.book_store.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author TaeWK
 */
public class Main {

    public static Scanner sc = new Scanner(System.in);

    public static Connection makeConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");

        String username = "root";
        String password = "1111";
        String url = "jdbc:mysql://localhost:3306/madang?serverTimezone=Asia/Seoul";

        Connection connection = DriverManager.getConnection(url, username, password);

        return connection;
    }

    public static int printMenuAndScan() {
        System.out.print("1.도서관리   2.고객관리   3.주문하기   4.종료 |  ");
        return sc.nextInt();
    }

    public static int printMenuAndScan_no_01() {
        System.out.print("1.도서추가   2.수정(가격수정)   3.삭제  4.전체리스트  5.이전으로  | ");
        return sc.nextInt();
    }

    public static void insert() throws SQLException, ClassNotFoundException {
        Scanner scan = new Scanner(System.in);
        System.out.println("ID 책이름 작가 가격");

        String dat = scan.nextLine();


        String[] datArr = dat.split(" ");

        String sql = "INSERT INTO BOOK VALUES (?,?,?,?)";

        PreparedStatement statement = makeConnection().prepareStatement(sql);

        statement.setInt(1,Integer.parseInt(datArr[0]));
        statement.setString(2,datArr[1]);
        statement.setString(3,datArr[2]);
        statement.setInt(4,Integer.parseInt(datArr[3]));

        for(String s: datArr)
            System.out.println(s);

        int rst = statement.executeUpdate();
        System.out.println(rst != 0 ? "실행 완료" : "실패");
    }

    public static void update() throws SQLException, ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("책 이름");
        String data = scanner.nextLine();

        System.out.println("바꿀 가격");
        int price = scanner.nextInt();

        String sql = "UPDATE BOOK SET PRICE=? WHERE BOOKNAME=?";

        PreparedStatement statement = makeConnection().prepareStatement(sql);

        statement.setInt(1, price);
        statement.setString(2, data);

        int rst = statement.executeUpdate();
        System.out.println(rst != 0 ? "실행 완료" : "실패");

    }

    public static void delete() throws SQLException, ClassNotFoundException {
        System.out.println("책 아이디를 입력하세요.");
        String bookname = sc.next();

        String sql = "DELETE FROM BOOK WHERE bookid=?";

        PreparedStatement statement = makeConnection().prepareStatement(sql);

        statement.setString(1,bookname);

        int rst = statement.executeUpdate();
        System.out.println(rst != 0 ? "실행 완료" : "실패");
    }

    public static void printList() throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM BOOK";

        Statement statement = makeConnection().createStatement();

        ResultSet set = statement.executeQuery(sql);

        while(set.next()){
            System.out.print("book_id:" + set.getInt("bookid") + "\t");
            System.out.print("book_name:" + set.getString("bookname") +"\t");
            System.out.print("publisher:" + set.getString("publisher") +"\t");
            System.out.println("price:" + set.getString("price") +"\t");
        }
    }






    public static void run() throws SQLException, ClassNotFoundException {
        while (true) {

            int menu_01 = printMenuAndScan();

            
            if(menu_01 == 1){
                System.out.println("도서관리");

                int menu_02 = printMenuAndScan_no_01();

                switch (menu_02){
                    case 1:
                        insert();
                        break;
                    case 2:
                        update();
                        break;
                    case 3:
                        delete();
                        break;
                    case 4:
                        printList();
                        break;
                    case 5:
                        break;



                }

            }else if(menu_01 == 2){
                System.out.println("고객관리");
            }else if(menu_01 == 3){
                System.out.println("주문");
                
            }else if(menu_01 == 4){
                System.out.println("종료");
                return;
            }
            


        }


    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        run();
    }


}
