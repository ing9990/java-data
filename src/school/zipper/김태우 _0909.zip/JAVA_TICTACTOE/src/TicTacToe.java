// �������̽��� ���� �⺻ ���̺귯��.

// --------------------
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

// --------------------
public class TicTacToe implements ActionListener {

	// random ���̺귯�� ��ü ����.
	Random random = new Random();
	
	// JFrame ���̺귯�� ��ü�� frame�̸����� ����.
	JFrame frame = new JFrame();
	
	// ���� ��ü
	JPanel title_panel = new JPanel();
	
	// ��ư ��ü
	JPanel button_panel = new JPanel();
	
	// O �Ǵ� X
	JLabel textfield = new JLabel();
	
	// ��ư ��ü. ( 9�� ���� )
	JButton[] buttons = new JButton[9];

	
	// player 1���� = player2_turn = false
	boolean player1_turn;
	boolean player2_turn;
	
	
	TicTacToe(){	
		
		// �⺻ CLOSE
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// ���� ���μ��� â ������. ���� 800px X 800px
		frame.setSize(800,800);
		
		// �� �׶��� �÷� ����.
		frame.getContentPane().setBackground(new Color(120,120,255));
		
		// ���̾ƿ� ����.
		frame.setLayout(new BorderLayout());
		frame.setVisible(true);
		
		textfield.setBackground(new Color(0,0,0));
		textfield.setForeground(new Color(255,255,255));
		textfield.setFont(new Font("��Ǯ�����Ϸ�",Font.BOLD,40));
		textfield.setHorizontalAlignment(JLabel.CENTER);
		textfield.setText("�ڹ� ƽ���� ����");
		textfield.setOpaque(true);
		
		title_panel.setLayout(new BorderLayout());
		title_panel.setBounds(120,120,800,100);
		
		button_panel.setLayout(new GridLayout(3,3));
		button_panel.setBackground(new Color(255,255,255));
		button_panel.setForeground(new Color(0,0,0));
		
		for(int i=0; i<9; i++) {
			buttons[i] = new JButton();
			button_panel.add(buttons[i]);
			buttons[i].setFont(new Font("��Ǯ�����Ϸ�",Font.BOLD,150));
			buttons[i].setFocusable(false);
			buttons[i].addActionListener(this);
		
		}
		
		title_panel.add(textfield);
		frame.add(title_panel,BorderLayout.NORTH);
		frame.add(button_panel);
		
		firstTurn();
		
				}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		for(int i =0; i<9; i++) {
			if(e.getSource()==buttons[i]) {
				if(player1_turn == true) {
					if(buttons[i].getText()=="") {
						buttons[i].setForeground(new Color(225,25,140));
						buttons[i].setText("X");
						player1_turn = false;
						textfield.setText("O ����");
						check();
					}
				}
				else {
					if(buttons[i].getText()=="") {
				}
					buttons[i].setForeground(new Color(150,100,255));
					buttons[i].setText("O");
					player1_turn = true;
					textfield.setText("X ����");
					check();
				}
			}		
		}	
	}
	// ó�� ���� �����ִ� �Լ�. random ���.
	public void firstTurn() {
		// Thread.sleep(ms) �� ����ؼ� ���ð��� �� ������.
		try {
		Thread.sleep(2000);
		}catch (InterruptedException e){
			e.printStackTrace();
	}
		// random.nextInt�� 0 , 1�� �̾Ƴ��� 0�̸� x�� 1�̸� o��.
		if(random.nextInt(2)==0) {
			player1_turn = true;
			textfield.setText("X ����");
		}
		else {
			player1_turn = false;
			textfield.setText("O ����");
		}
	}

	// ���� �¸��� üũ�ϴ� �Լ�.
	public void check(){
		if(
				(buttons[0].getText() == "X") &&
				(buttons[1].getText() == "X") && 
				(buttons[2].getText() == "X")
				) {
			xWins(0,1,2);
		}
		if(
				(buttons[3].getText() == "X") &&
				(buttons[4].getText() == "X") && 
				(buttons[5].getText() == "X")
				) {
			xWins(3,4,5);
		}
		if(
				(buttons[0].getText() == "X") &&
				(buttons[3].getText() == "X") && 
				(buttons[6].getText() == "X")
				) {
			xWins(0,3,6);
		}
		if(
				(buttons[1].getText() == "X") &&
				(buttons[4].getText() == "X") && 
				(buttons[7].getText() == "X")
				) {
			xWins(1,4,7);
		}
		if(
				(buttons[2].getText() == "X") &&
				(buttons[5].getText() == "X") && 
				(buttons[8].getText() == "X")
				) {
			xWins(2,5,8);
		}
		if(
				(buttons[0].getText() == "X") &&
				(buttons[4].getText() == "X") && 
				(buttons[8].getText() == "X")
				) {
			xWins(0,4,8);
		}
		if(
				(buttons[2].getText() == "X") &&
				(buttons[4].getText() == "X") && 
				(buttons[6].getText() == "X")
				) {
			xWins(2,4,6);
		}
		//  O�� �¸��� ��Ȳ
		if(
				(buttons[0].getText() == "O") &&
				(buttons[1].getText() == "O") && 
				(buttons[2].getText() == "O")
				) {
			oWins(0,1,2);
		}
		if(
				(buttons[3].getText() == "O") &&
				(buttons[4].getText() == "O") && 
				(buttons[5].getText() == "O")
				) {
			oWins(3,4,5);
		}
		if(
				(buttons[0].getText() == "O") &&
				(buttons[3].getText() == "O") && 
				(buttons[6].getText() == "O")
				) {
			oWins(0,3,6);
		}
		if(
				(buttons[1].getText() == "O") &&
				(buttons[4].getText() == "O") && 
				(buttons[7].getText() == "O")
				) {
			oWins(1,4,7);
		}
		if(
				(buttons[2].getText() == "O") &&
				(buttons[5].getText() == "O") && 
				(buttons[8].getText() == "O")
				) {
			oWins(2,5,8);
		}
		if(
				(buttons[0].getText() == "O") &&
				(buttons[4].getText() == "O") && 
				(buttons[8].getText() == "O")
				) {
			oWins(0,4,8);
		}
		if(
				(buttons[2].getText() == "O") &&
				(buttons[4].getText() == "O") && 
				(buttons[6].getText() == "O")
				) {
			oWins(2,4,6);
		}	
	}
	// wins�Լ�.
	public void xWins(int a,int b,int c) {
		buttons[a].setBackground(Color.red);
		buttons[b].setBackground(Color.red);
		buttons[c].setBackground(Color.red);
		
		for(int i = 0; i<9; i++) {
			buttons[i].setEnabled(false);
		}
		textfield.setText("X �¸�");
	}
	public void oWins(int a,int b,int c) {
		
		buttons[a].setBackground(Color.red);
		buttons[b].setBackground(Color.red);
		buttons[c].setBackground(Color.red);
		
		for(int i = 0; i<9; i++) {
			buttons[i].setEnabled(false);
		}
		textfield.setText("O �¸�");
	}
}