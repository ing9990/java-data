import java.util.Scanner;

public class seatTheater {	
	
	static void printLine(String[] s)
	{
		System.out.println("\n- - - - - - - - - - - - - - - - - ");
		
		System.out.println("1  2  3  4  5  6  7  8  9  10");
		
		System.out.println("- - - - - - - - - - - - - - - - - ");
		
		for(int i = 0; i<10; i++)
			System.out.print(s[i]+"  ");
		
		System.out.println("\n- - - - - - - - - - - - - - - - -");
		
		System.out.print("\n���Ͻô� �¼���ȣ�� �Է��ϼ��� (����� -1) :  ");
	}
	
	public static void main(String[] args) 
	{
		String[] seat = {"0" ,"0" ,"0" ,"0" ,"0" ,"0" ,"0" ,"0" ,"0" ,"0"} ;
		
		Scanner sc = new Scanner(System.in);
		
		int num;
		
		while(true)
		{
			printLine(seat);
			
			num = sc.nextInt();
			
				if(seat[num].equals("1"))
					System.out.println("�̹� ����� �ڸ��Դϴ�.");
			
			switch(num) 
			{
			case 1: seat[0] = "1"; break;
			case 2: seat[1] = "1"; break;
			case 3: seat[2] = "1"; break;
			case 4: seat[3] = "1"; break;
			case 5: seat[4] = "1"; break;
			case 6: seat[5] = "1"; break;
			case 7: seat[6] = "1"; break;
			case 8: seat[7] = "1"; break;
			case 9: seat[8] = "1"; break;
		   case 10: seat[9] = "1"; break;
		   case -1: break;
		   default: break;
			}	
		}
	}
}
