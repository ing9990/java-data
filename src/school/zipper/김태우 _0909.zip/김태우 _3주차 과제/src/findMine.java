
public class findMine {

	public static void main(String[] args) {
		
		int m = Integer.parseInt(args[0]);
		int n = Integer.parseInt(args[1]);
		
		double p = Double.parseDouble(args[2]);
		
		boolean[][] boombs = new boolean[m+2][n+2];
		
		for(int i = 1; i<=m; i++)
			for(int j = 1; j<=n; j++)
				boombs[i][j] = (Math.random() < p);
		
		for(int i = 1; i<= m; i++)
		{
			for(int j =1; j<= n; j++)
				if(boombs[i][j])
					System.out.print("* ");
				else
					System.out.print("- ");
			System.out.println();
		}

	}

}
