import java.util.Scanner;

public class numList {

    public static void main(String[] args) {
       
    	
        Scanner sc = new Scanner(System.in);
        
        String[] barGragh = {"","","","","","","","","",""};
        
        int num;
        
        System.out.println("���ڸ� 10�� �Է��ϼ���.");
        
        for(int i=0; i<10; i++)
        {
        	num = sc.nextInt();
            
            if(num<0 || num > 99)
                i--;
            else 
            	barGragh[num / 10] += "*";
        }
        
        for(int i = 0; i < 10; i++)
        {
            System.out.printf("%d ~ %d : %s\n", i*10 , 9+i*10, barGragh[i]);
        }
    }
}