import java.util.ArrayList;

public class minValue {

	public static void main(String[] args) {
	
		ArrayList<Integer> value = new ArrayList<>();
		
		value.add(20);
		value.add(27);
		value.add(92);
		value.add(18);
		value.add(4);
		
		int s[] = {12,3,19,6,18,8,12,4,1,19};
		
		int min = 100;
		
		int arrMin = 100;
		
		for(int i =0; i<s.length; i++)
		{
			if(min > s[i])
				min = s[i];
		}
		System.out.println(min);
		
		for(int i = 0; i<value.size(); i++)
		{
			if(arrMin > value.get(i))
				arrMin = value.get(i);
		}
		
		System.out.println("�ּڰ��� " + arrMin);
		

	}

}
