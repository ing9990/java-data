package java1123;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class IteratorTest {

	public static void main(String[] args) {
		
		ArrayList<String> arr = new ArrayList<String>();
		Vector<String> vArr = new Vector<String>();
		
		arr.add("ȫ�浿");
		arr.add("��浿");
		arr.add("�̱浿");
		arr.add("�ڱ浿");
		vArr.add("ȫ�浿");
		vArr.add("��浿");
		vArr.add("�̱浿");
		vArr.add("�ڱ浿");

		System.out.println("---- for �� ----");
		
		for (int i = 0; i <arr.size(); i++)
			System.out.print(arr.get(i)+" ");
		System.out.println();
		
		System.out.println("\n---- forEach �� ----");
		
		for ( String s : arr)
			System.out.print(s+" ");
		System.out.println();
		
		System.out.println("\n----Iterator ----");
		Iterator<String> it = arr.iterator();
		Iterator<String> vit = vArr.iterator();
		
		while (it.hasNext())
			System.out.print(it.next()+"|");
		System.out.println();
		
		System.out.println("\n----Vector Iterator ----");
		while (vit.hasNext())
			System.out.print(vit.next()+" ");
		
	
		
	}

}
