package java1123;
import java.util.*;

class Person{
	String name;
	int age;
	
	Person(String name,int age){
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person["+this.name+","+this.age+"]  ";
	}
	@Override
	public int hashCode() {
		return name.hashCode()+age; 
	}
}

public class HashsetTestDemo {

	public static void main(String[] args) {
		Set<Person> set = new HashSet<>();
		
		set.add(new Person("�迭��",20));
		set.add(new Person("����",16));
		set.add(new Person("�ְ���",56));
		set.add(new Person("���ڹ�",35));
		
		set.forEach(s -> System.out.println(s.name+" : "+s.age));
		System.out.println();
		Iterator<Person> it = set.iterator();
		
		while(it.hasNext()) {
			System.out.print(it.next()+" ");
		}
	}

}
