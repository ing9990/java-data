package java1123;

import java.util.*;

public class List1Test {

	public static void main(String[] args) {

		ArrayList<String> arr = new ArrayList<>();
		
		arr.add("���ű�");
		arr.add("����");
		arr.add("�ٶ���");
		arr.add("��");
		
		arr.removeIf(x -> x.length() !=2);
		
		arr.forEach(item -> System.out.println("item : " + item));
		

	}

}
