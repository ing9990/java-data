package java1123;
import java.util.*;
public class asd {

	public static void main(String[] args) {
		Random r = new Random();
		int ans = r.nextInt(5);

		System.out.println(ans);
	}

}
