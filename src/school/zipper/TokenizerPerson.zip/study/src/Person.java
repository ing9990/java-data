public class Person {
String name;
String age;
String tel;

public Person(String name,String age,String tel) {
	this.name = name;
	this.age = age;
	this.tel = tel;
}

public void getInfo() {
	System.out.printf("�̸� = %s,���� = %s, = ��ȭ��ȣ = %s",name,age,tel);
}

@Override
public String toString() {
	return "Person[name= "+this.name+"\ttel= "+this.tel+"\tage= "+this.age;
	}
}
