import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) {
		ArrayList<Person> arr = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		
		
		while(true) {
			System.out.print("1.�߰� 2.��ü����Ʈ 3.����  : ");
			int menu = sc.nextInt();			
			
			
			switch (menu){
			case 1:
				System.out.println("\n�̸�/����/��ȭ��ȣ");
				String s = sc.next();
				System.out.println();
				StringTokenizer st = new StringTokenizer(s,"/");
				
					String name = (String) st.nextElement();
					String age = st.nextToken();
					String tel = st.nextToken();
					
				arr.add(new Person(name,age,tel));
				System.out.println("\n");
				break;
			case 2:
				
				for (int i = 0; i<arr.size(); i++) {
					System.out.printf("%d�� ° ��� : ",i+1);
					System.out.println(arr.get(i).toString());
					System.out.println("\n");
				}
				System.out.println();
				break;
			
			case 3:
				System.out.println("���� �޴��Դϴ�.");
				System.out.println("\n");
				break;
			}
		}
	}

}
