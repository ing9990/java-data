package JavaBook.����ó��;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int n1;
		int n2;
		int n3;
		int sum = 0;
		boolean flag = true;
	
			while (flag){
				try {
				System.out.print("n1 : ");
				n1 = sc.nextInt();
				System.out.print("n2 : ");
				n2 = sc.nextInt();
				System.out.print("n3 :");
				n3 = sc.nextInt();
			
			sum = n1 + n2 + n3;
			}catch(InputMismatchException e) {
				System.out.println("���Է�");
				sc.next();
				continue;
			}
			System.out.println("�� :"+sum);
			flag = false;
			break;
		
		}
	}

}
