package school.poly.book_store.db;

import java.sql.SQLException;

/**
 * @author TaeWK
 */
public class Main {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Book_store.run();
    }
}
